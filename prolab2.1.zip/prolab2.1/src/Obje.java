
public abstract class Obje extends Lokasyon {
   abstract void objeOlustur();
}
