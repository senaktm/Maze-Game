
public abstract class Puan {

	 abstract void PuanGoster();




}
